﻿원문 전체 SRT · 2026-10-18 · 1.1.131

총 558곡, 996개 SRT
노래 기록 558개 / 원본 타임스탬프 438개

SRT/노래기록: 날짜별 노래 기록 자막
SRT/원본타임스탬프: 원곡 타임스탬프 자막
곡 목록: 유형별 곡명·원곡자·SRT 위치와 타임스탬프 미확보 곡 목록

원문 가사만 표시합니다.
Inst와 자료를 연결한 뒤 타이밍을 확인하며 편집하세요.
사용 매뉴얼: https://rekatime.pages.dev/data/porting/rekatime-porting-manual.html
